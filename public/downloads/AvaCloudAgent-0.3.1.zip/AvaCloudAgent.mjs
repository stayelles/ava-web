#!/usr/bin/env node
import { existsSync, readFileSync, writeFileSync, mkdirSync, unlinkSync, readdirSync, statSync, appendFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { spawn, execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createHash } from 'node:crypto'

const execFileAsync = promisify(execFile)

const DEFAULT_ENDPOINT = 'https://bmcvyvyjqxehwmkddtya.supabase.co/functions/v1/ava-cloud-agent'
const CONFIG_PATH = process.env.AVA_CLOUD_CONFIG || 'C:\\ProgramData\\AvaCloud\\agent.json'
const POLL_MS = Number(process.env.AVA_CLOUD_POLL_MS || 5000)
const HEARTBEAT_MS = Number(process.env.AVA_CLOUD_HEARTBEAT_MS || 30000)
const UPDATE_CHECK_MS = Number(process.env.AVA_CLOUD_UPDATE_CHECK_MS || 15 * 60 * 1000)
const AGENT_VERSION = '0.3.1'
const COMMAND_DIR = process.env.AVA_CLOUD_COMMAND_DIR || 'C:\\ProgramData\\AvaCloud'
const DESKTOP_COMMAND_PATH = join(COMMAND_DIR, 'desktop-command.json')
const DESKTOP_RESULT_PATH = join(COMMAND_DIR, 'desktop-command-result.json')
const LOG_PATH = join(COMMAND_DIR, 'agent.log')
let lastMissingStatusLogAt = 0

function log(message, payload = null) {
  try {
    mkdirSync(COMMAND_DIR, { recursive: true })
    const suffix = payload ? ` ${JSON.stringify(payload).slice(0, 1400)}` : ''
    appendFileSync(LOG_PATH, `[${new Date().toISOString()}] ${message}${suffix}\n`, 'utf8')
  } catch {}
}

function isRecord(value) {
  return value && typeof value === 'object' && !Array.isArray(value)
}

function loadConfig() {
  const fileConfig = existsSync(CONFIG_PATH) ? JSON.parse(readFileSync(CONFIG_PATH, 'utf8')) : {}
  return {
    endpoint: process.env.AVA_CLOUD_AGENT_ENDPOINT || fileConfig.endpoint || DEFAULT_ENDPOINT,
    userId: process.env.AVA_CLOUD_USER_ID || fileConfig.user_id || fileConfig.userId || '',
    agentToken: process.env.AVA_CLOUD_AGENT_TOKEN || fileConfig.agent_token || fileConfig.agentToken || '',
    avaExe: process.env.AVA_CLOUD_AVA_EXE || fileConfig.ava_exe || fileConfig.avaExe || 'C:\\Program Files\\Ava\\Ava.exe',
    mt5Exe: process.env.AVA_CLOUD_MT5_EXE || fileConfig.mt5_exe || fileConfig.mt5Exe || 'C:\\Program Files\\MetaTrader 5\\terminal64.exe',
    statusPath: process.env.AVA_CLOUD_STATUS_PATH || fileConfig.status_path || fileConfig.statusPath || '',
    updateManifestUrl: process.env.AVA_CLOUD_UPDATE_MANIFEST_URL || fileConfig.update_manifest_url || fileConfig.updateManifestUrl || 'https://call-ava.com/downloads/ava-cloud-manifest.json',
    bridgeExpertsPath: process.env.AVA_CLOUD_BRIDGE_EXPERTS_PATH || fileConfig.bridge_experts_path || fileConfig.bridgeExpertsPath || '',
  }
}

const config = loadConfig()

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

async function api(action, payload = {}) {
  const res = await fetch(config.endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action,
      user_id: config.userId,
      agent_token: config.agentToken,
      ...payload,
    }),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok || data.ok === false) throw new Error(data.error || `Agent API ${res.status}`)
  return data
}

async function powershell(script, timeoutMs = 30000) {
  const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script], {
    windowsHide: true,
    timeout: timeoutMs,
    maxBuffer: 1024 * 1024,
  })
  return stdout.trim()
}

function compareVersions(a = '', b = '') {
  const left = String(a).split('.').map(n => Number.parseInt(n, 10) || 0)
  const right = String(b).split('.').map(n => Number.parseInt(n, 10) || 0)
  for (let i = 0; i < Math.max(left.length, right.length); i += 1) {
    if ((left[i] || 0) > (right[i] || 0)) return 1
    if ((left[i] || 0) < (right[i] || 0)) return -1
  }
  return 0
}

async function downloadFile(url, outputPath) {
  await powershell(`$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri "${url.replace(/"/g, '""')}" -OutFile "${outputPath.replace(/"/g, '""')}"`)
}

function fileSha256(path) {
  const hash = createHash('sha256')
  hash.update(readFileSync(path))
  return hash.digest('hex')
}

async function isProcessRunning(name) {
  try {
    const out = await powershell(`Get-Process -Name "${name}" -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Id`)
    return !!out
  } catch {
    return false
  }
}

async function getFileVersion(path) {
  if (!path || !existsSync(path)) return null
  try {
    const escaped = path.replace(/'/g, "''")
    const out = await powershell(`(Get-Item '${escaped}').VersionInfo.ProductVersion`)
    return out || null
  } catch {
    return null
  }
}

async function getScheduledTaskInfo(taskName) {
  try {
    const escaped = taskName.replace(/'/g, "''")
    const out = await powershell(`$task = Get-ScheduledTask -TaskName '${escaped}' -ErrorAction SilentlyContinue; $info = Get-ScheduledTaskInfo -TaskName '${escaped}' -ErrorAction SilentlyContinue; if ($task) { [pscustomobject]@{ State=$task.State; LastRunTime=$info.LastRunTime; LastTaskResult=$info.LastTaskResult; NextRunTime=$info.NextRunTime } | ConvertTo-Json -Compress }`)
    return out ? JSON.parse(out) : null
  } catch {
    return null
  }
}

function latestFiles(paths, limit = 8) {
  const files = []
  for (const base of paths.filter(Boolean)) {
    try {
      if (!existsSync(base)) continue
      const entries = readdirSync(base)
      for (const name of entries) {
        const full = join(base, name)
        const stat = statSync(full)
        if (stat.isFile()) files.push({ path: full, name, size: stat.size, mtimeMs: stat.mtimeMs })
      }
    } catch {}
  }
  return files
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
    .slice(0, limit)
    .map(file => ({
      path: file.path,
      name: file.name,
      size: file.size,
      updated_at: new Date(file.mtimeMs).toISOString(),
    }))
}

function tailFile(path, maxBytes = 12000) {
  try {
    if (!path || !existsSync(path)) return null
    const raw = readFileSync(path)
    return raw.subarray(Math.max(0, raw.length - maxBytes)).toString('utf8').slice(-maxBytes)
  } catch (error) {
    return `Impossible de lire ${path}: ${error.message}`
  }
}

function supportLogPaths() {
  const appData = process.env.APPDATA || ''
  const localAppData = process.env.LOCALAPPDATA || ''
  const programData = process.env.ProgramData || 'C:\\ProgramData'
  const statusPath = findStatusPath()
  return [
    statusPath,
    join(programData, 'AvaCloud', 'agent.log'),
    join(programData, 'AvaCloud', 'update.log'),
    join(appData, 'Ava', 'logs', 'today.txt'),
    join(appData, 'Ava', 'logs', 'ava.log'),
    join(localAppData, 'Ava', 'logs', 'main.log'),
  ].filter(Boolean)
}

async function checkVersions() {
  const bridge = readBridgeStatus()
  const avaRunning = await isProcessRunning('Ava')
  const mt5Running = await isProcessRunning('terminal64')
  const avaVersion = await getFileVersion(config.avaExe)
  const manifest = await fetchUpdateManifest().catch(error => ({ error: error.message }))
  return {
    checked_at: new Date().toISOString(),
    machine: {
      hostname: process.env.COMPUTERNAME || null,
      username: process.env.USERNAME || null,
    },
    processes: {
      ava_running: avaRunning,
      mt5_running: mt5Running,
    },
    versions: {
      ava: avaVersion || process.env.AVA_CLOUD_AVA_VERSION || null,
      bridge: bridge.bridge_version || null,
      agent: AGENT_VERSION,
      manifest_ava: manifest?.ava?.version || null,
      manifest_bridge: manifest?.bridge?.version || null,
      manifest_agent: manifest?.agent?.version || null,
    },
    paths: {
      ava_exe: config.avaExe,
      mt5_exe: config.mt5Exe,
      status_path: bridge.metrics?.status_path || null,
      command_dir: COMMAND_DIR,
      bridge_experts_path: config.bridgeExpertsPath || null,
      update_manifest_url: config.updateManifestUrl,
    },
    scheduled_task: await getScheduledTaskInfo('AvaCloudAgent'),
    bridge,
    manifest_error: manifest?.error || null,
  }
}

function findStatusPath() {
  const commonRoot = join(process.env.APPDATA || '', 'MetaQuotes', 'Terminal', 'Common', 'Files', 'AvaTrading')
  const symbolsRoot = join(commonRoot, 'symbols')
  const candidates = [
    config.statusPath,
    join(commonRoot, 'ava_status.json'),
    join(symbolsRoot, 'XAUUSD', 'ava_status.json'),
    join(symbolsRoot, 'frxXAUUSD', 'ava_status.json'),
    join(symbolsRoot, 'GOLD', 'ava_status.json'),
    join(symbolsRoot, 'BOOM1000', 'ava_status.json'),
    join(symbolsRoot, 'Boom 1000 Index', 'ava_status.json'),
    'C:\\Users\\Administrator\\AppData\\Roaming\\MetaQuotes\\Terminal\\Common\\Files\\AvaTrading\\ava_status.json',
  ].filter(Boolean)
  try {
    if (existsSync(symbolsRoot)) {
      for (const name of readdirSync(symbolsRoot)) candidates.push(join(symbolsRoot, name, 'ava_status.json'))
    }
  } catch {}
  const existing = candidates
    .filter(path => existsSync(path))
    .map(path => ({ path, mtimeMs: statSync(path).mtimeMs }))
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
  return existing[0]?.path || ''
}

function safeArray(value, limit = 20) {
  return Array.isArray(value) ? value.slice(0, limit) : []
}

function maskAccount(value) {
  const raw = String(value || '')
  if (raw.length <= 4) return raw
  return `${raw.slice(0, 2)}••••${raw.slice(-3)}`
}

function readBridgeStatus() {
  const path = findStatusPath()
  if (!path) {
    if (Date.now() - lastMissingStatusLogAt > 60000) {
      lastMissingStatusLogAt = Date.now()
      log('ava_status.json introuvable', {
        appdata: process.env.APPDATA || null,
        command_dir: COMMAND_DIR,
      })
    }
    return { bridge_connected: false, metrics: { status_error: 'ava_status.json introuvable' } }
  }
  try {
    const raw = JSON.parse(readFileSync(path, 'utf8'))
    const updatedAt = Date.parse(raw.updated_at || raw.time || raw.timestamp || '')
    const fresh = Number.isFinite(updatedAt) ? Date.now() - updatedAt < 120000 : true
    const positions = safeArray(raw.positions || raw.open_positions_list || raw.openTrades, 30)
    const recentTrades = safeArray(raw.recent_trades || raw.trades || raw.closed_trades || raw.history, 30)
    const journal = safeArray(raw.journal || raw.logs || raw.recent_logs, 20).map(item => String(item).slice(0, 300))
    const login = raw.login || raw.account_login || raw.account || raw.mt5_login
    const server = raw.server || raw.account_server || raw.mt5_server
    return {
      bridge_connected: fresh,
      mt5_connected: fresh,
      bridge_version: raw.version || raw.bridge_version || null,
      active_market: raw.symbol || raw.market || raw.active_market || null,
      balance: Number(raw.balance ?? raw.account_balance ?? NaN),
      equity: Number(raw.equity ?? raw.account_equity ?? NaN),
      floating_profit: Number(raw.floating_profit ?? raw.profit ?? NaN),
      positions_count: Number(raw.positions_count ?? raw.open_positions ?? raw.positions?.length ?? 0),
      metrics: {
        status_path: path,
        bridge_message: raw.message || raw.last_message || null,
        account: {
          login: maskAccount(login),
          server: server || null,
          currency: raw.currency || raw.account_currency || null,
        },
        positions,
        recent_trades: recentTrades,
        journal,
        bridge_raw_keys: Object.keys(raw).slice(0, 80),
      },
    }
  } catch (error) {
    log('Lecture ava_status.json impossible', { path, error: error.message })
    return { bridge_connected: false, metrics: { status_error: error.message, status_path: path } }
  }
}

async function heartbeat() {
  const bridge = readBridgeStatus()
  const avaRunning = await isProcessRunning('Ava')
  const mt5Running = await isProcessRunning('terminal64')
  const avaVersion = await getFileVersion(config.avaExe)
  let desktopResult = null
  let desktopStatus = null
  if (avaRunning) {
    try {
      desktopResult = await sendDesktopStructured('volatility_status', { heartbeat: true }, 5000)
      desktopStatus = extractDesktopStatus(desktopResult)
    } catch (error) {
      log('Statut Ava Desktop indisponible', { error: error.message })
    }
  }
  const desktopCloudConfig = isRecord(desktopStatus?.cloud_config) ? desktopStatus.cloud_config : null
  const desktopConfigUpdatedAt = String(desktopStatus?.desktop_config_updated_at || new Date().toISOString())
  await api('heartbeat', {
    state: avaRunning ? 'online' : 'ready',
    ava_running: avaRunning,
    mt5_connected: Boolean(bridge.mt5_connected || mt5Running),
    bridge_connected: Boolean(bridge.bridge_connected),
    ava_version: avaVersion || process.env.AVA_CLOUD_AVA_VERSION || null,
    bridge_version: bridge.bridge_version || null,
    agent_version: AGENT_VERSION,
    active_market: bridge.active_market || null,
    balance: Number.isFinite(bridge.balance) ? bridge.balance : null,
    equity: Number.isFinite(bridge.equity) ? bridge.equity : null,
    floating_profit: Number.isFinite(bridge.floating_profit) ? bridge.floating_profit : null,
    positions_count: Number.isFinite(bridge.positions_count) ? bridge.positions_count : null,
    cloud_config: desktopCloudConfig || undefined,
    cloud_config_source: desktopCloudConfig ? 'desktop' : undefined,
    desktop_config_updated_at: desktopCloudConfig ? desktopConfigUpdatedAt : undefined,
    metrics: {
      ...(bridge.metrics || {}),
      desktop_status: desktopStatus || undefined,
      cloud_config: desktopCloudConfig || undefined,
      cloud_config_source: desktopCloudConfig ? 'desktop' : undefined,
      desktop_config_updated_at: desktopCloudConfig ? desktopConfigUpdatedAt : undefined,
      desktop: {
        ava_process: avaRunning,
        mt5_process: mt5Running,
        desktop_command_ok: desktopResult ? desktopResult.ok !== false : null,
        desktop_command_pending: Boolean(desktopResult?.pending),
        hostname: process.env.COMPUTERNAME || null,
        username: process.env.USERNAME || null,
        command_dir: COMMAND_DIR,
        ava_exe: config.avaExe,
        mt5_exe: config.mt5Exe,
        update_manifest_url: config.updateManifestUrl,
      },
    },
  })
}

function startDetached(file, args = []) {
  const child = spawn(file, args, { detached: true, stdio: 'ignore', windowsHide: true })
  child.unref()
}

async function startAva() {
  if (!(await isProcessRunning('Ava'))) startDetached(config.avaExe)
}

async function stopAva() {
  await powershell('Get-Process -Name "Ava" -ErrorAction SilentlyContinue | Stop-Process -Force')
}

async function restartAva() {
  await stopAva()
  await sleep(1500)
  await startAva()
}

async function restartMt5() {
  await powershell('Get-Process -Name "terminal64" -ErrorAction SilentlyContinue | Stop-Process -Force')
  await sleep(1500)
  startDetached(config.mt5Exe)
}

function writeDesktopCommand(type, payload = {}) {
  mkdirSync(COMMAND_DIR, { recursive: true })
  const command = {
    id: `cloud-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type,
    payload,
    source: 'ava_cloud_agent',
    created_at: new Date().toISOString(),
  }
  try { unlinkSync(DESKTOP_RESULT_PATH) } catch {}
  writeFileSync(DESKTOP_COMMAND_PATH, JSON.stringify(command, null, 2), 'utf8')
  return command
}

async function waitDesktopResult(commandId, timeoutMs = 20000) {
  const started = Date.now()
  while (Date.now() - started < timeoutMs) {
    if (existsSync(DESKTOP_RESULT_PATH)) {
      try {
        const result = JSON.parse(readFileSync(DESKTOP_RESULT_PATH, 'utf8'))
        if (!result.command_id || result.command_id === commandId) return result
      } catch {}
    }
    await sleep(500)
  }
  return { ok: false, pending: true, message: 'Ava Desktop n’a pas encore confirme la commande.' }
}

function extractDesktopStatus(desktopResult) {
  if (!isRecord(desktopResult)) return null
  const result = isRecord(desktopResult.result) ? desktopResult.result : desktopResult
  const status = isRecord(result.status) ? result.status : result
  return isRecord(status) ? status : null
}

async function sendDesktopStructured(type, payload = {}, timeoutMs = 20000) {
  const command = writeDesktopCommand(type, payload)
  const result = await waitDesktopResult(command.id, timeoutMs)
  return { command_id: command.id, ...result }
}

async function fetchUpdateManifest() {
  if (!config.updateManifestUrl) return null
  const res = await fetch(config.updateManifestUrl, { cache: 'no-store' })
  if (!res.ok) throw new Error(`Manifest update ${res.status}`)
  return res.json()
}

async function updateAva(manifest) {
  const ava = manifest?.ava || manifest?.desktop || {}
  const targetVersion = String(ava.version || '')
  const url = String(ava.windows_url || ava.url || '')
  if (!targetVersion || !url) return { skipped: true, reason: 'Ava manifest incomplete' }
  const current = String(process.env.AVA_CLOUD_AVA_VERSION || '')
  if (current && compareVersions(current, targetVersion) >= 0) return { skipped: true, version: current }
  const installer = `C:\\ProgramData\\AvaCloud\\AvaSetup-${targetVersion}.exe`
  await downloadFile(url, installer)
  await stopAva()
  const args = String(ava.silent_args || '/S')
  await powershell(`Start-Process -FilePath "${installer}" -ArgumentList "${args.replace(/"/g, '""')}" -Wait`)
  await startAva()
  return { updated: true, version: targetVersion }
}

async function updateBridge(manifest) {
  const bridge = manifest?.bridge || manifest?.avaBridge || {}
  const targetVersion = String(bridge.version || '')
  const url = String(bridge.url || bridge.windows_url || '')
  const expertsPath = String(config.bridgeExpertsPath || bridge.experts_path || '')
  if (!targetVersion || !url || !expertsPath) return { skipped: true, reason: 'AvaBridge manifest incomplete' }
  const target = `${expertsPath}\\AvaBridgeEA-${targetVersion}.ex5`
  const live = `${expertsPath}\\AvaBridgeEA.ex5`
  await downloadFile(url, target)
  await powershell(`Copy-Item -Path "${target}" -Destination "${live}" -Force`)
  return { updated: true, version: targetVersion, target }
}

async function updateAgent(manifest) {
  const agent = manifest?.agent || {}
  const targetVersion = String(agent.version || '')
  const url = String(agent.url || agent.windows_url || '')
  if (!targetVersion || !url) return { skipped: true, reason: 'Agent manifest incomplete' }
  if (compareVersions(AGENT_VERSION, targetVersion) >= 0) return { skipped: true, version: AGENT_VERSION }
  const archive = `C:\\ProgramData\\AvaCloud\\AvaCloudAgent-${targetVersion}.zip`
  const extractDir = `C:\\ProgramData\\AvaCloud\\agent-${targetVersion}`
  await downloadFile(url, archive)
  if (agent.sha256) {
    const actual = fileSha256(archive)
    if (actual.toLowerCase() !== String(agent.sha256).toLowerCase()) {
      throw new Error(`AvaCloudAgent package checksum mismatch: ${actual}`)
    }
  }
  await powershell(`Remove-Item -Recurse -Force "${extractDir}" -ErrorAction SilentlyContinue; Expand-Archive -Path "${archive}" -DestinationPath "${extractDir}" -Force`)
  const scriptDir = dirname(process.argv[1] || 'C:\\Program Files\\AvaCloudAgent\\AvaCloudAgent.mjs')
  await powershell(`Copy-Item -Path "${extractDir}\\AvaCloudAgent.mjs" -Destination "${join(scriptDir, 'AvaCloudAgent.mjs')}" -Force; if (Test-Path "${extractDir}\\install-service.ps1") { Copy-Item -Path "${extractDir}\\install-service.ps1" -Destination "${join(scriptDir, 'install-service.ps1')}" -Force }`)
  setTimeout(() => process.exit(0), 1000)
  return { updated: true, version: targetVersion, restart_required: true }
}

async function runUpdate(kind = 'all') {
  const manifest = await fetchUpdateManifest()
  const result = {}
  if (kind === 'all' || kind === 'ava') result.ava = await updateAva(manifest)
  if (kind === 'all' || kind === 'bridge') result.bridge = await updateBridge(manifest)
  if (kind === 'all' || kind === 'agent') result.agent = await updateAgent(manifest)
  await api('event', { level: 'info', type: 'auto_update', message: 'Mise a jour Ava Cloud verifiee.', payload: result })
  return result
}

async function collectLogs() {
  const paths = supportLogPaths()
  const latest = latestFiles([
    join(process.env.ProgramData || 'C:\\ProgramData', 'AvaCloud'),
    join(process.env.APPDATA || '', 'Ava', 'logs'),
    join(process.env.LOCALAPPDATA || '', 'Ava', 'logs'),
  ])
  const logs = {}
  for (const path of paths.slice(0, 10)) logs[path] = tailFile(path)
  return {
    collected_at: new Date().toISOString(),
    versions: await checkVersions(),
    latest_files: latest,
    logs,
  }
}

function validateSupportShell(command) {
  const text = String(command || '').trim()
  if (!text || text.length > 1200) throw new Error('Commande support invalide ou trop longue.')
  const lowered = text.toLowerCase()
  const blocked = [
    'remove-item', ' rm ', 'del ', 'erase ', 'format ', 'shutdown', 'restart-computer',
    'stop-computer', 'net user', 'set-localuser', 'new-localuser', 'reg delete',
    'invoke-expression', 'iex ', 'downloadstring', 'start-bitstransfer',
    'set-executionpolicy', 'disable-', 'enable-psremoting',
  ]
  if (blocked.some(pattern => lowered.includes(pattern))) {
    throw new Error('Commande support refusee par le garde-fou Ava Cloud.')
  }
  const allowedPrefixes = [
    'get-', 'test-', 'select-', 'where-', 'measure-', 'resolve-', 'convertto-json',
    'type ', 'gc ', 'cat ', 'dir ', 'ls ', 'whoami', 'hostname', '$',
  ]
  if (!allowedPrefixes.some(prefix => lowered.startsWith(prefix))) {
    throw new Error('Commande support limitee aux diagnostics en lecture seule.')
  }
  return text
}

async function runSupportShell(payload = {}) {
  const command = validateSupportShell(payload.command)
  const output = await powershell(command, Math.max(3000, Math.min(Number(payload.timeout_ms || 10000), 20000)))
  return {
    command,
    output: output.slice(-20000),
    ran_at: new Date().toISOString(),
  }
}

async function handleCommand(command) {
  if (!command?.id) return
  let commandResult = { handled_at: new Date().toISOString() }
  try {
    if (command.type === 'start_ava') await startAva()
    else if (command.type === 'stop_ava') await stopAva()
    else if (command.type === 'restart_ava') await restartAva()
    else if (command.type === 'restart_mt5') await restartMt5()
    else if (command.type === 'update_ava') await runUpdate('ava')
    else if (command.type === 'update_bridge') await runUpdate('bridge')
    else if (command.type === 'update_agent') await runUpdate('agent')
    else if (command.type === 'update_all') await runUpdate('all')
    else if (command.type === 'check_versions') {
      const result = await checkVersions()
      await api('event', { level: 'info', type: 'support_check_versions', message: 'Versions Ava Cloud verifiees.', payload: result })
      await api('result', { command_id: command.id, success: true, result })
      return
    }
    else if (command.type === 'collect_logs') {
      const result = await collectLogs()
      await api('event', { level: 'info', type: 'support_collect_logs', message: 'Diagnostic support Ava Cloud collecte.', payload: { latest_files: result.latest_files, versions: result.versions } })
      await api('result', { command_id: command.id, success: true, result })
      return
    }
    else if (command.type === 'support_shell') {
      const result = await runSupportShell(command.payload || {})
      await api('event', { level: 'warning', type: 'support_shell', message: 'Commande support diagnostic executee.', payload: { command: result.command } })
      await api('result', { command_id: command.id, success: true, result })
      return
    }
    else if (command.type === 'apply_config') {
      const desktopResult = await sendDesktopStructured('volatility_apply_config', command.payload || {})
      commandResult = { ...commandResult, desktop: desktopResult }
      await api('event', { level: 'info', type: 'config_received', message: 'Configuration recue par Ava Cloud.', payload: { cloud: command.payload || {}, desktop: desktopResult } })
    } else if (command.type === 'diagnose') {
      const desktopResult = await sendDesktopStructured('volatility_status', { diagnose: true })
      commandResult = { ...commandResult, desktop: desktopResult }
      await api('event', { level: desktopResult.ok === false ? 'warning' : 'info', type: 'diagnostic', message: desktopResult.ok === false ? 'Diagnostic Ava Desktop incomplet.' : 'Diagnostic Ava Desktop reçu.', payload: desktopResult })
    } else if (command.type === 'natural_command') {
      const desktopResult = await sendDesktopStructured('volatility_natural_command', command.payload || {})
      commandResult = { ...commandResult, desktop: desktopResult }
      await api('event', { level: 'info', type: 'natural_command', message: 'Commande Ava traitee depuis Ava Web.', payload: desktopResult })
    } else if (command.type === 'save_preset' || command.type === 'delete_preset') {
      await api('event', { level: 'info', type: command.type, message: 'Preset Ava Cloud synchronise.', payload: command.payload || {} })
    } else if (command.type !== 'refresh_status') {
      throw new Error(`Commande inconnue: ${command.type}`)
    }
    await heartbeat()
    await api('result', { command_id: command.id, success: true, result: commandResult })
  } catch (error) {
    log('Commande Ava Cloud en erreur', { id: command.id, type: command.type, error: error.message || String(error) })
    await api('result', { command_id: command.id, success: false, error: error.message || String(error) })
  }
}

async function loop() {
  if (!config.userId || !config.agentToken) {
    throw new Error('AVA_CLOUD_USER_ID et AVA_CLOUD_AGENT_TOKEN sont requis.')
  }
  let nextHeartbeat = 0
  let nextUpdateCheck = 0
  while (true) {
    const now = Date.now()
    if (now >= nextHeartbeat) {
      await heartbeat().catch(error => console.error('[AvaCloudAgent] heartbeat', error.message))
      nextHeartbeat = now + HEARTBEAT_MS
    }
    if (now >= nextUpdateCheck) {
      await runUpdate('all').catch(error => console.error('[AvaCloudAgent] update', error.message))
      nextUpdateCheck = now + UPDATE_CHECK_MS
    }
    const polled = await api('poll').catch(error => {
      console.error('[AvaCloudAgent] poll', error.message)
      return null
    })
    if (polled?.command) await handleCommand(polled.command)
    if (process.argv.includes('--once')) return
    await sleep(POLL_MS)
  }
}

loop().catch(error => {
  console.error('[AvaCloudAgent]', error)
  process.exitCode = 1
})
