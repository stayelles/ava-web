param(
  [Parameter(Mandatory=$true)][string]$UserId,
  [Parameter(Mandatory=$true)][string]$AgentToken,
  [string]$Endpoint = "https://bmcvyvyjqxehwmkddtya.supabase.co/functions/v1/ava-cloud-agent",
  [string]$AgentScript = "C:\Program Files\AvaCloudAgent\AvaCloudAgent.mjs",
  [string]$NodeExe = "C:\Program Files\nodejs\node.exe",
  [string]$AvaExe = "C:\Program Files\Ava\Ava.exe",
  [string]$Mt5Exe = "C:\Program Files\MetaTrader 5\terminal64.exe",
  [string]$UpdateManifestUrl = "https://call-ava.com/downloads/ava-cloud-manifest.json",
  [string]$BridgeExpertsPath = ""
)

$ErrorActionPreference = "Stop"
$configDir = "C:\ProgramData\AvaCloud"
$configPath = Join-Path $configDir "agent.json"
New-Item -ItemType Directory -Force -Path $configDir | Out-Null

$config = @{
  endpoint = $Endpoint
  user_id = $UserId
  agent_token = $AgentToken
  ava_exe = $AvaExe
  mt5_exe = $Mt5Exe
  update_manifest_url = $UpdateManifestUrl
  bridge_experts_path = $BridgeExpertsPath
} | ConvertTo-Json -Depth 4

Set-Content -Path $configPath -Value $config -Encoding UTF8

$action = New-ScheduledTaskAction -Execute $NodeExe -Argument "`"$AgentScript`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)

Register-ScheduledTask -TaskName "AvaCloudAgent" -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Start-ScheduledTask -TaskName "AvaCloudAgent"
Write-Host "AvaCloudAgent installé et démarré."
